package com.cg.capbook.beans;

public enum Gender {
	MALE,
	FEMALE
}
