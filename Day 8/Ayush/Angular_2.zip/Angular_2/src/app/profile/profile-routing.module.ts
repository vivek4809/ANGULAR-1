import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { ProfileAboutComponent } from './profile-about/profile-about.component';
import { ProfileLayoutComponent } from './profile-layout.component';
import { ProfilePageComponent } from './profile-page/profile-page.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlbumComponent } from './album/album.component';

const routes: Routes = [
  {path: '', component: ProfileLayoutComponent, children: [
    {path: '', component: ProfilePageComponent},
    {path: 'album', component: AlbumComponent},
    {path: 'about', component: ProfileAboutComponent},
    {path: 'editProfile', component: UpdateProfileComponent}
  ]},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileRoutingModule { }
