package com.cg.capbook.beans;

public class Profile {
	private int profileID;
	private String bio;
	private User user;
}
