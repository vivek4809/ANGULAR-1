import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interfaces/User/user';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  allUsers: User[];
  error: string;
  _searchPeople = false;
  _friendName: string;
  _findUser:string='';
  

  get friendName(): string {
    return this._friendName;
  }

  set friendName(value: string) {
    this._friendName = value;
  }
  
  constructor(private capbookServices: CapbookServicesService, private route: ActivatedRoute, private router: Router) { 
    this._findUser="";
  }

  ngOnInit() {
  }

  resetFields() {
    this._searchPeople = false;
  }

  allUserDetails() {
    this._searchPeople = true;
    this.capbookServices.getAllUsers().subscribe(
      temp=>{
        this.allUsers=temp;
        console.log(JSON.stringify(this.allUsers));
      },
      error=>{
        this.error=error;
      }
    );
  }
}
