import { Photo } from './../../interfaces/Photo/photo';
import { DatePipe } from '@angular/common';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from './../../interfaces/Post/post';
import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  bio = 'Add Bio!!';
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _posts: Post[];
  _postText: string;
  _photoCaption: string;
  _changePhoto = false;
  _changeProfilePhoto = false;
  _changeWallPhoto = false;
  _showWallPicChangeSection = false;
  errorMessage: string;

  imageUrl: string;
  fileToUpload: File = null;
  selectedFiles: FileList;
  retrieveFiles: Photo[];
  currentFileUpload: File;
  fileData: Photo;
  progress: { percentage: number } = { percentage: 0 };
  byteData: Blob;

  _allUserPhotos: Photo[];


  constructor(private route: ActivatedRoute, private router: Router,
    private capbookService: CapbookServicesService, private datePipe: DatePipe) { }

  get postText(): string {
    return this._postText;
  }
  set postText(value: string) {
    this._postText = value;
  }
  get photoCaption(): string {
    return this._photoCaption;
  }
  set photoCaption(value: string) {
    this._photoCaption = value;
  }
  ngOnInit() {
    this._changeProfilePhoto = false;
    this.getAllPosts();
    this.getAllUserPhotos();
  }

  changePhotoHover() {
    this._changePhoto = !this._changePhoto;
  }

  changeWallPhotoHover() {
    this._changeWallPhoto = !this._changeWallPhoto;
  }

  changeProfilePhotoHover() {
    this._changeProfilePhoto = true;
  }

  resetFields() {
    this._changeProfilePhoto = false;
    this._showWallPicChangeSection = false;
    this.ngOnInit();
  }

  resetFields2() {
    console.log('closing');
    this._showWallPicChangeSection = false;
    this.ngOnInit();
  }

  showWallPicChange() {
    this._showWallPicChangeSection = true;
  }

  deletePost(postID: number) {
    const post: any = {
      postID : postID
    };
    this.capbookService.deletePost(post).subscribe(
      success => {
        this.ngOnInit();
      }
    );
  }

  createPost() {
    const _postDate = new Date();
    const post: any = {
      postText: this.postText,
      postDate: this.datePipe.transform(_postDate, 'yyyy-MM-dd'),
      postTime: this.datePipe.transform(_postDate, 'HH:mm:ss'),
      likesCount: 0,
      dislikesCount: 0,
      profile: this._user.profile
    };
    console.log(JSON.stringify(post));
    this.capbookService.updateStatus(post).subscribe(
      user => {
        this.ngOnInit();
        }
    ,
      error => {
        this.errorMessage = 'Status Not Updated!!';
      }
  );
  }

  getAllPosts() {
    this.capbookService.getAllPosts(this._user).subscribe(
        tempPosts => {
          this._posts = tempPosts;
        },
        error => {
          this.errorMessage = 'No posts found!!';
        }
    );
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    const reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
    reader.readAsDataURL(this.fileToUpload);
  }

  upload(albumName: string) {
    const uploadPhoto: any = {
      photoDate: this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
      photoTime: this.datePipe.transform(new Date(), 'HH:mm:ss')
    };
    this.progress.percentage = 0;
    this.capbookService.pushFileToStorage(this.fileToUpload, this._user.profile.profileID, albumName, uploadPhoto).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
        window.location.reload();
      }
    });
    this.selectedFiles = undefined;
  }

  getAllUserPhotos() {
    this._changeProfilePhoto = false;
    this.capbookService.getAllUserPhotos(this._user.profile).subscribe(
      photoList => {
        this._allUserPhotos = photoList;
      }
    );
  }
}
