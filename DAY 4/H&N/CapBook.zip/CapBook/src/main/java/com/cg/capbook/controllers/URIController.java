package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cg.capbook.beans.UploadForm;

@Controller
public class URIController {
	
	/*@GetMapping("/")
    public String index() {
        return "upload";
    }
	
	@GetMapping("/uploadMulti")
    public String uploadStatus() {
        return "uploadStatus";
    }*/
	
	@ModelAttribute
	public UploadForm getUploadForm() {
		return new UploadForm();
	}

}
