import { Component, OnInit } from '@angular/core';
import { Product } from '../products/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {
  searchProductsTitle: string = 'Search Product';

  _productId: number = 0;
  error: string;
  product: Product;

  constructor(private productService: ProductService) {
    this._productId = 0;
  }

  get productId(): number {
    return this._productId;
  }

  set productId(value: number) {
    this._productId = value;
  }


  ngOnInit() {
  }

  findProduct(): void {
    this.productService.getProductDetails(this.productId).subscribe(
      tempProduct => {
        this.product = tempProduct;
      }
    ,
    error => {
      this.error = error;
    }
  );
  }

}
