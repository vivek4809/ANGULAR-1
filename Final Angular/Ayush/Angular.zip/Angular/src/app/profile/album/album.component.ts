import { Photo } from './../../interfaces/Photo/photo';
import { DatePipe } from '@angular/common';
import { Album } from './../../interfaces/Album/album';
import { User } from './../../interfaces/User/user';
import { CapbookServicesService } from './../../services/capbook-services.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {

  _albumList: Album[];
  _photosList: Photo[];
  _albumName: string;
  _addAlbum = false;
  _albumMap = new Map();
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _flag: boolean;
  get albumName(): string {
    return this._albumName;
  }

  set albumName(value: string) {
    this._albumName = value;
  }

  constructor(private capbookService: CapbookServicesService, private datePipe: DatePipe) { }

  ngOnInit() {
    this._flag = false;
    this.getAllUserPhotos();
    this.capbookService.getAllUserAlbums(this._user.profile).subscribe(
      albumList => {
        this._albumList = albumList;
        for (let i = 0; i < this._albumList.length; i++) {
          console.log(this._albumList[i].albumName);
          this.getAllAlbumPhotos(this._albumList[i].albumName);
        }
      },
      error => {}
    );
    /* if (!this._albumList) {console.log('waiting!!'); } */
  }

  createNewAlbum() {
    this._addAlbum = true;
  }

  test() {console.log('testing'); }
  resetFields() {
    this._addAlbum = false;
  }

  onClick() {
    const album: any = {
      albumName: this.albumName,
      albumDate: this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
      albumTime: this.datePipe.transform(new Date(), 'HH:mm:ss'),
      profile: this._user.profile
    };
    console.log(JSON.stringify(album));
    this.capbookService.createNewAlbum(album).subscribe(
      _album => {
        this.ngOnInit();
      },
      error => {}
    );
  }

  /* getAllAlbums() {
    this.capbookService.getAllUserAlbums(this._user.profile).subscribe(
        albumList => {
          albumList.forEach(function (value) {
            console.log('album: ' + JSON.stringify(value));
            console.log('album: ' + JSON.stringify(value));
            this.capbookService.getAllAlbumPhotos(value.albumName).subscribe(
              photos => {
                console.log('album1111 ' + JSON.stringify(photos));
                /* this._albumMap.set(value.albumName, photos);
              }
              error => {}
            );
            this._photosList = this.getAllAlbumPhotos(value.albumName);
            /*console.log('album22 ' + JSON.stringify(this._photosList[0]));
          });
        },
        error => {}
    );
  } */

  getAllUserPhotos() {
    this.capbookService.getAllUserPhotos(this._user.profile).subscribe(
      photosList => {
        this._photosList = photosList;
      }
    );
  }

  getAllAlbumPhotos(albumName) {
    const album: any = {
      albumName: albumName,
      profile: this._user.profile
    };
    this.capbookService.getAllAlbumPhotos(album).subscribe(
      photos => {
        this._photosList = photos;
        this._albumMap.set(albumName, photos[0]);
      },
      error => {}
    );
  }

  /* getAllAlbumPhotos(albumName) {
    this.capbookService.getAllAlbumPhotos(albumName).subscribe(
      photos => {
        this._photosList = photos;
        console.log('album1111 ' + JSON.stringify(this._photosList[0]));
      },
      error => {}
    );
  } */
}
/* this.capbookService.getAllAlbumPhotos(value).subscribe(
              photos => {
                console.log('photo');
                this._albumMap.set(value.albumName, photos);
              }
            );
          }); */
