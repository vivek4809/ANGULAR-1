package com.cg.capbook.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;
import com.cg.capbook.services.CapbookServices;

@RestController
@CrossOrigin
public class CapbookController {
	@Autowired
	private CapbookServices capbookServices;

	@RequestMapping(value="/registerCustomer", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> registerUser(@RequestBody User user) {
		try {
			capbookServices.registerCustomer(user);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/getLoginAction", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		try {
			user = capbookServices.customerLogin(user.getEmailID(), user.getPassword());
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException | UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/getUserDetails", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<User> getUserDetails(@RequestBody User user) {
		try {
			System.out.println("Email: " + user.getEmailID());
			user = capbookServices.getUserDetails(user.getEmailID());
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/updateUserDetails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateUserDetails(@RequestBody User user) {
		try {
			User userToUpdate = capbookServices.getUserDetails(user.getEmailID());
			userToUpdate.setPassword(user.getPassword());
			capbookServices.updateUserDetails(userToUpdate);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
