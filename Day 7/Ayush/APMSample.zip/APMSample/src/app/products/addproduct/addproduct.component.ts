import { ProductService } from './../../services/product.service';
import { Product } from './../product';
import { Component, OnInit } from '@angular/core';
import { componentNeedsResolution } from '@angular/core/src/metadata/resource_loading';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  productListTitle: string = 'Add Product Details!';
  product: Product;
  _productId: number = 0;
  _productName: string = '';
  _productCode: string = '';
  _description: string = '';
  _starRating: number = 0;
  _price: number = 0;
  _releaseDate: string = '';
  error: string;
  successMessage: string;
  enableDeleteSection: boolean;
  addForm: FormGroup;
  submitted = false;

  constructor(private productService: ProductService, private router: Router, private formBuilder: FormBuilder) { }

  get productId(): number {
    return this._productId;
  }

  set productId(value: number) {
    this._productId = value;
  }

  get productName(): string {
    return this._productName;
  }

  set productName(value: string) {
    this._productName = value;
  }

  get productCode(): string {
    return this._productCode;
  }

  set productCode(value: string) {
    this._productCode = value;
  }

  get description(): string {
    return this._description;
  }

  set description(value: string) {
    this._description = value;
  }

  get starRating(): number {
    return this._starRating;
  }

  set starRating(value: number) {
    this._starRating = value;
  }

  get price(): number {
    return this._price;
  }

  set price(value: number) {
    this._price = value;
  }

  get releaseDate(): string {
    return this._releaseDate;
  }

  set releaseDate(value: string) {
    this._releaseDate = value;
  }

  ngOnInit() {
    this.enableDeleteSection = true;
    this.addForm = this.formBuilder.group({
      productId: ['', Validators.required]
  });
  }

  get f() { return this.addForm.controls; }

  addProduct(): void {
    console.log('here');
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    this.enableDeleteSection = false;
    const productObj: any = {
      productId : this.productId,
      productName : this.productName,
      productCode : this.productCode,
      description : this.description,
      starRating : this.starRating,
      price : this.price,
      releaseDate : this.releaseDate
    };

    this.productService.addProductDetails(productObj).subscribe(
        success => {
          this.successMessage = 'Product Added Successfully!';
        }
      ,
        error => {
          this.error = error;
          console.log(error);
        }
    );
  }

  public navigateBack(): void {
    this.router.navigate(['/products']);
  }
}
