
package com.cg.capbook.daoservices;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.cg.capbook.beans.FriendList;

public interface FriendListDAO extends JpaRepository<FriendList, Integer>{
	
	@Query("select  f.senderEmail from FriendList f  where f.receiverEmail=:receiverEmail or f.senderEmail=:receiverEmail")
	ArrayList<String> getAllFriendsList(@Param("receiverEmail")String receiverEmail); 
	
	@Query("select  f from FriendList f  where f.senderEmail=:senderEmail and f.receiverEmail=:receiverEmail")
	FriendList checkFriendList(@Param("senderEmail")String senderEmail,@Param("receiverEmail")String receiverEmail); 
	
	@Query("select  f from FriendList f  where f.receiverEmail=:receiverEmail")
	List<FriendList> getFriendList(@Param("receiverEmail")String receiverEmail); 

}