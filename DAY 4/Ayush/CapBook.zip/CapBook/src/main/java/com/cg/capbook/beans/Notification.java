package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Notification {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="notificationIDGenerator")
	@SequenceGenerator(name="notificationIDGenerator", initialValue=1, allocationSize=0)
	private int notificationID;
	private String notificationText;
	private String notificationDate, notificationTime;
	@ManyToOne
	private Post post;
	@ManyToOne
	private Photo photo;
	@ManyToOne
	private Profile profile;
}
