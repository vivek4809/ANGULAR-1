package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="postIDGenerator")
	@SequenceGenerator(name="postIDGenerator", initialValue=1, allocationSize=0)
	private int postID;
	private String postText;
	private String postDate, postTime;
	private int likesCount, dislikesCount;
	@ManyToOne
	private Profile profile;
	//	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	//	@MapKey
	//	private Map<String, Comment> comments;
	//	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, orphanRemoval=true, mappedBy="profile")
	//	@MapKey
	//	private Map<String, User> taggedFriends;
	public Post() {}
	public Post(String postText, String postDate, String postTime, int likesCount, int dislikesCount) {
		super();
		this.postText = postText;
		this.postDate = postDate;
		this.postTime = postTime;
		this.likesCount = likesCount;
		this.dislikesCount = dislikesCount;
	}
	public Post(String postText, String postDate, String postTime, int likesCount, int dislikesCount, Profile profile) {
		super();
		this.postText = postText;
		this.postDate = postDate;
		this.postTime = postTime;
		this.likesCount = likesCount;
		this.dislikesCount = dislikesCount;
		this.profile = profile;
	}
	public Post(int postID, String postText, String postDate, String postTime, int likesCount, int dislikesCount,
			Profile profile) {
		super();
		this.postID = postID;
		this.postText = postText;
		this.postDate = postDate;
		this.postTime = postTime;
		this.likesCount = likesCount;
		this.dislikesCount = dislikesCount;
		this.profile = profile;
	}
	public int getPostID() {
		return postID;
	}
	public void setPostID(int postID) {
		this.postID = postID;
	}
	public String getPostText() {
		return postText;
	}
	public void setPostText(String postText) {
		this.postText = postText;
	}
	public String getPostDate() {
		return postDate;
	}
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}
	public String getPostTime() {
		return postTime;
	}
	public void setPostTime(String postTime) {
		this.postTime = postTime;
	}
	public int getLikesCount() {
		return likesCount;
	}
	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}
	public int getDislikesCount() {
		return dislikesCount;
	}
	public void setDislikesCount(int dislikesCount) {
		this.dislikesCount = dislikesCount;
	}
	public Profile getProfile() {
		return profile;
	}
	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	@Override
	public String toString() {
		return "Post [postID=" + postID + ", postText=" + postText + ", postDate=" + postDate + ", postTime=" + postTime
				+ ", likesCount=" + likesCount + ", dislikesCount=" + dislikesCount + ", profile=" + profile + "]";
	}

}
