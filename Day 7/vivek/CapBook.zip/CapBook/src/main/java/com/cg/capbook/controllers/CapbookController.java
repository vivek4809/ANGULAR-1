package com.cg.capbook.controllers;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.xerces.impl.dv.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.capbook.beans.Photo;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.PhotoStorageException;
import com.cg.capbook.exceptions.PostsNotFoundException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
import com.cg.capbook.services.CapbookServices;

@RestController
@CrossOrigin
public class CapbookController {
	@Autowired
	private CapbookServices capbookServices;
	
	private static String UPLOADED_FOLDER = "D:\\Users\\ayusgoel\\Desktop\\Capbook Images\\";

	@RequestMapping(value="/registerCustomer", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> registerUser(@RequestBody User user) {
		try {
			user = capbookServices.registerCustomer(user);
			Profile profile = new Profile();
			profile.setUser(user);
			user.setProfile(profile);
			user = capbookServices.saveUserDetails(user); 
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/getLoginAction", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	/*@RequestMapping(value="/getLoginAction", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)*/
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		try {
			System.out.println("Heelo here");
			user = capbookServices.customerLogin(user.getEmailID(), user.getPassword());
			System.out.println(user.toString());
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException | UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/getUserDetails", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<User> getUserDetails(@RequestBody User user) {
		try {
			System.out.println("Email: " + user.getEmailID());
			user = capbookServices.getUserDetails(user.getEmailID());
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(value="/updateUserDetails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateUserDetails(@RequestBody User user) {
		try {
			User userToUpdate = capbookServices.getUserDetails(user.getEmailID());
			userToUpdate.setPassword(user.getPassword());
			capbookServices.updateUserDetails(userToUpdate);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/getUserProfile", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Profile> getUserProfile(@RequestBody Profile profile) {
		try {
			profile = capbookServices.getUserProfileById(profile.getProfileID());
			return new ResponseEntity<>(profile, HttpStatus.OK);
		} catch (UserProfileNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/updateUserProfile", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Profile> updateUserProfile(@RequestBody Profile profile) {
		try {
			Profile profileToUpdate = capbookServices.getUserProfileById(profile.getProfileID());
			profileToUpdate.setBio(profile.getBio());
			profileToUpdate.setWork(profile.getWork());
			profileToUpdate.setEducation(profile.getEducation());
			profileToUpdate.setRelationship(profile.getRelationship());
			profileToUpdate.setCurrentCity(profile.getCurrentCity());
			profileToUpdate.setHomeTown(profile.getHomeTown());
			profile = capbookServices.setUserProfile(profileToUpdate);
			return new ResponseEntity<>(profile, HttpStatus.OK);
		} catch (UserProfileNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/updatePost", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
//	@RequestMapping(value="/updatePost", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Post> updatePost(@RequestBody Post post) throws UserProfileNotFoundException {
		System.out.println("EMail   " + post.getProfile().getProfileID());
		Profile profile = capbookServices.getUserProfileById(post.getProfile().getProfileID());
		post.setProfile(profile);
		post = capbookServices.updatePost(post);
		return new ResponseEntity<>(post, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getAllPosts", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
//	@RequestMapping(value="/getAllPosts", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Post>> getAllPosts(@RequestBody User user) {
		try {
			Profile profile = capbookServices.getUserProfile(user.getEmailID());
			List<Post> posts = capbookServices.getAllPosts(profile.getProfileID());
			return new ResponseEntity<>(posts, HttpStatus.OK);
		} catch (UserProfileNotFoundException | PostsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/api/file/upload")
    public String uploadMultipartFile(@RequestParam("file") MultipartFile photo, @RequestParam("emailID") String emailID) {
    	try {
    		Photo photos = new Photo(photo.getOriginalFilename(), photo.getContentType(), photo.getBytes());
    		capbookServices.storePhoto(photos);
       		 byte[] bytes = photo.getBytes();
             Path path = Paths.get(UPLOADED_FOLDER + photo.getOriginalFilename());
             Files.write(path, bytes);    		
	    	return "File uploaded successfully! -> filename = " + photo.getOriginalFilename();
		} 
    		catch (Exception e) {
			return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
		}   
    }
	
	@RequestMapping(value="/api/file/retrieve")
	public ResponseEntity<Photo> getAllPhotos(){
		try {
			List<Photo> photosList=capbookServices.retrieveAllPhotos();
			Photo pic = photosList.get(0); 
			return new ResponseEntity<> (pic, HttpStatus.OK);
		} catch (PhotoStorageException e) {
			e.printStackTrace();
			System.out.println("not ok");
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	
		}
	}
	
	
	
}
