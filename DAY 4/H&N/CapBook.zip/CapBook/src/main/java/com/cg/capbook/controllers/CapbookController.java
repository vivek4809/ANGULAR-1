package com.cg.capbook.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cg.capbook.beans.Photos;
import com.cg.capbook.beans.UploadForm;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.PhotoStorageException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;
import com.cg.capbook.services.CapbookServices;

import cucumber.api.java.it.Data;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
@RestController
@CrossOrigin
public class CapbookController {
	@Autowired
	private CapbookServices capbookServices;
	
	
	private static String UPLOADED_FOLDER = "C:\\Users\\hitgoyal\\Downloads\\CapbookImages\\";
	
	@RequestMapping(value="/registerCustomer", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> registerUser(@RequestBody User user) {
		try {
			capbookServices.registerCustomer(user);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/getLoginAction", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		try {
			user = capbookServices.customerLogin(user.getEmailID(), user.getPassword());
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException | UserInvalidDetailsException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/getUserDetails", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<User> getUserDetails(@RequestParam("emailID") String emailID) {
		try {
			User user = capbookServices.getUserDetails(emailID);
			return new ResponseEntity<>(user, HttpStatus.OK);
		} catch (UserDetailsNotFoundException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(value="/updateUserDetails", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateUserDetails(@RequestBody User user) {
			capbookServices.updateUserDetails(user);
			return new ResponseEntity<>(HttpStatus.OK);
	}
    
	@PostMapping("/api/file/upload")
    public String uploadMultipartFile(@RequestParam("file") MultipartFile photo) {
    	try {
    		Photos photos = new Photos(photo.getOriginalFilename(), photo.getContentType(), photo.getBytes());
    		System.out.println(capbookServices.storePhoto(photos));
       		 byte[] bytes = photo.getBytes();
             Path path = Paths.get(UPLOADED_FOLDER + photo.getOriginalFilename());
             Files.write(path, bytes);    		
	    	return "File uploaded successfully! -> filename = " + photo.getOriginalFilename();
		} 
    		catch (Exception e) {
			return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
		}   
    }
	
	@RequestMapping(value="/api/file/retrieve")
	public ResponseEntity<byte[]> getAllPhotos(){
		try {
			List<Photos> photosList=capbookServices.retrieveAllPhotos();
			System.out.println(photosList);
			System.out.println("Size:  " + photosList.size());
			Photos pic = photosList.get(0); 
			/*for (Photos photos1 : photosList) {
				String id = photos1.getPhotoId();
				byte[] bytes = photos1.getData();
                photos1.setData(bytes);
			}*/
			return new ResponseEntity<byte[]> (pic.getData(), HttpStatus.OK);
		} catch (PhotoStorageException e) {
			e.printStackTrace();
			System.out.println("not ok");
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	
		}
	}
}
