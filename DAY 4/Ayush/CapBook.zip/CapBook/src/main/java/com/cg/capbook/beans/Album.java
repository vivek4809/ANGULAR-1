package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
public class Album {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="albumIDGenerator")
	@SequenceGenerator(name="albumIDGenerator", initialValue=1, allocationSize=0)
	private int albumID;
	private String albumName;
	private String albumDate, albumTime;
	@ManyToOne
	private Profile profile;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="album")
	@MapKey
	private Map<Integer, Photo> photos;
}
