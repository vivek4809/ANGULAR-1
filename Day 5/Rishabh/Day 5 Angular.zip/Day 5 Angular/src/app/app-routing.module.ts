import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './UserActivities/welcome/welcome.component';
import { SigninComponent } from './UserActivities/signin/signin.component';
import { SignupComponent } from './UserActivities/signup/signup.component';
import { ForgotPasswordComponent } from './UserActivities/forgotPassword/forgot-password.component';

const routes: Routes = [
      {path: 'welcome', component: WelcomeComponent},
      {path: 'signin', component: SigninComponent },
      {path: 'signup', component: SignupComponent},
      {path: 'forgotPassword', component: ForgotPasswordComponent},
      {path: 'homePage', loadChildren: './home/home.module#HomeModule'},
      {path: 'profile', loadChildren: './profile/profile.module#ProfileModule'},
      {path: '', redirectTo: 'signin', pathMatch: 'full'}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
