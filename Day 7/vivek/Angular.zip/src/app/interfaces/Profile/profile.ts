export interface Profile {
    profileID:number;
    bio: string;
    work: string;
    education: string;
    relationship: string;
    currentCity: string;
    homeTown: string;
    joiningDate:string;
}
