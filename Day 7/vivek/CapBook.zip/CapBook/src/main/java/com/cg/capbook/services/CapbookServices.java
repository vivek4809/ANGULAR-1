package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.Photo;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.PhotoStorageException;
import com.cg.capbook.exceptions.PostsNotFoundException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;

public interface CapbookServices {
	public User customerLogin(String emailID, String password) throws UserDetailsNotFoundException, UserInvalidDetailsException;
	public User registerCustomer(User user) throws UserInvalidDetailsException;
	public User updateUserDetails(User user);
	public User getUserDetails(String emailID) throws UserDetailsNotFoundException;
	public Photo storePhoto(Photo photo) throws PhotoStorageException;
	public List<Photo> retrieveAllPhotos() throws PhotoStorageException;
	public Profile  getUserProfile(String emailID) throws UserProfileNotFoundException;
	public Profile setUserProfile(Profile profile);
	public User saveUserDetails(User user);
	public Post updatePost(Post post);
	public List<Post> getAllPosts(int profileID) throws PostsNotFoundException;
	public Profile getUserProfileById(int profileID) throws UserProfileNotFoundException;
}
