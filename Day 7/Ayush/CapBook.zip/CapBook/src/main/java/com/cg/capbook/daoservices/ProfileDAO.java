package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Profile;

public interface ProfileDAO extends JpaRepository<Profile, Integer> {
	@Query("SELECT p FROM Profile p WHERE p.user.emailID = :emailID")
	public Profile getUserProfile(@Param("emailID") String emailID);
}
