package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Album {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="albumIDGenerator")
	@SequenceGenerator(name="albumIDGenerator", initialValue=1, allocationSize=0)
	private int albumID;
	private String albumName;
	private String albumDate, albumTime;
	@ManyToOne
	@JsonManagedReference
	private Profile profile;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="album")
	@MapKey
	@JsonBackReference
	private Map<Integer, Photo> photos;
	public Album() {}
	public Album(String albumName, String albumDate, String albumTime, Profile profile, Map<Integer, Photo> photos) {
		super();
		this.albumName = albumName;
		this.albumDate = albumDate;
		this.albumTime = albumTime;
		this.profile = profile;
		this.photos = photos;
	}
	public Album(int albumID, String albumName, String albumDate, String albumTime, Profile profile,
			Map<Integer, Photo> photos) {
		super();
		this.albumID = albumID;
		this.albumName = albumName;
		this.albumDate = albumDate;
		this.albumTime = albumTime;
		this.profile = profile;
		this.photos = photos;
	}
	public int getAlbumID() {
		return albumID;
	}
	public void setAlbumID(int albumID) {
		this.albumID = albumID;
	}
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public String getAlbumDate() {
		return albumDate;
	}
	public void setAlbumDate(String albumDate) {
		this.albumDate = albumDate;
	}
	public String getAlbumTime() {
		return albumTime;
	}
	public void setAlbumTime(String albumTime) {
		this.albumTime = albumTime;
	}
	public Profile getProfile() {
		return profile;
	}
	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	public Map<Integer, Photo> getPhotos() {
		return photos;
	}
	public void setPhotos(Map<Integer, Photo> photos) {
		this.photos = photos;
	}
	@Override
	public String toString() {
		return "Album [albumID=" + albumID + ", albumName=" + albumName + ", albumDate=" + albumDate + ", albumTime="
				+ albumTime + ", profile=" + profile + ", photos=" + photos + "]";
	}
}
