import { User } from './../../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  _fullName: string;
  constructor() { }

  ngOnInit() {
    const user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
    this._fullName = user.firstName + ' ' + user.lastName;
  }

}
