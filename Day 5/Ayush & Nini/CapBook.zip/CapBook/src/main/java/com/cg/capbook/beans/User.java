package com.cg.capbook.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="CapbookUser")
public class User {
	@Id
	private String emailID;
	private String firstName,lastName,dateOfBirth,password;
	private int age;
	private long mobileNo;
	private String gender;
	private String firstSecurityAnswer, secondSecurityAnswer;
	@OneToOne(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="user")
	@JsonManagedReference
	private Profile profile;
	public User() {}
	public User(String emailID, String firstName, String lastName, String dateOfBirth, String password, int age,
			long mobileNo, String gender, String firstSecurityAnswer, String secondSecurityAnswer) {
		super();
		this.emailID = emailID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.age = age;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.firstSecurityAnswer = firstSecurityAnswer;
		this.secondSecurityAnswer = secondSecurityAnswer;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getFirstSecurityAnswer() {
		return firstSecurityAnswer;
	}
	public void setFirstSecurityAnswer(String firstSecurityAnswer) {
		this.firstSecurityAnswer = firstSecurityAnswer;
	}
	public String getSecondSecurityAnswer() {
		return secondSecurityAnswer;
	}
	public void setSecondSecurityAnswer(String secondSecurityAnswer) {
		this.secondSecurityAnswer = secondSecurityAnswer;
	}
	public Profile getProfile() {
		return profile;
	}
	public void setProfile(Profile profile) {
		this.profile = profile;
	}
	@Override
	public String toString() {
		return "User [emailID=" + emailID + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", password=" + password + ", age=" + age + ", mobileNo=" + mobileNo + ", gender="
				+ gender + ", firstSecurityAnswer=" + firstSecurityAnswer + ", secondSecurityAnswer="
				+ secondSecurityAnswer + "]";
	}
}
