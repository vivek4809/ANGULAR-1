package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
@Entity
public class Profile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="profileIDGenerator")
	@SequenceGenerator(name="profileIDGenerator", initialValue=1, allocationSize=0)
	private int profileID;
	private String bio, about, work, education, relationship, currentCity, homeTown;
	private String joiningDate;
	@OneToOne(cascade=CascadeType.ALL, orphanRemoval=true)
	private Photo profilePic;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Album> albums;
	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, mappedBy="")
	@MapKey
	private Map<String, User> friends;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Post> posts;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Message> messages;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Notification> notifications;
	@OneToOne
	private User user;
}
