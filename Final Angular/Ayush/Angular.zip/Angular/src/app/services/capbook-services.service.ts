import { Photo } from './../interfaces/Photo/photo';
import { Profile } from './../interfaces/Profile/profile';
import { Post } from './../interfaces/Post/post';
import { User } from './../interfaces/User/user';
import { Injectable } from '@angular/core';
import {Observer, Observable, throwError } from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import { HttpClient, HttpErrorResponse, HttpParams, HttpEvent, HttpRequest } from '@angular/common/http';
import { Album } from '../interfaces/Album/album';



@Injectable({
  providedIn: 'root'
})
export class CapbookServicesService {

  private url = 'http://localhost:4444/';
  constructor(private httpClient: HttpClient) { }

  public acceptUserDetails(user: any): Observable<void> {
    return this.httpClient.post<void>(this.url + 'registerCustomer', user, {}).pipe(catchError(this.handleError));
  }

  public login(user: any): Observable<User> {
    return this.httpClient.post<User>(this.url + 'getLoginAction', user, {}).pipe(catchError(this.handleError));
  }

  public fetchUserDetails(user: any): Observable<User> {
    return this.httpClient.post<User>(this.url + 'getUserDetails', user, {}).pipe(catchError(this.handleError));
  }

  public changePassword(user: any): Observable<void> {
    return this.httpClient.post<void>(this.url + 'updateUserDetails', user, {}).pipe(catchError(this.handleError));
  }

  public getProfileDetails(profile: any): Observable<Profile> {
    return this.httpClient.post<Profile>(this.url + 'getUserProfile', profile, {}).
      pipe(catchError(this.handleError));
  }

  public getAllUserAlbums(profile: any): Observable<Album[]> {
    return this.httpClient.post<Album[]>(this.url + 'getAllAlbums', profile, {}).pipe(catchError(this.handleError));
  }

  public createNewAlbum(album: any): Observable<Album> {
    return this.httpClient.post<Album>(this.url + 'createNewAlbum', album, {}).pipe(catchError(this.handleError));
  }

  public updateStatus(post: any): Observable<void> {
    return this.httpClient.post<void>(this.url + 'updatePost', post, {}).pipe(catchError(this.handleError));
  }

  public deletePost(post: any): Observable<void> {
    return this.httpClient.post<void>(this.url + 'deletePost', post, {}).pipe(catchError(this.handleError));
  }

  public getAllPosts(user: any): Observable<Post[]> {
    return this.httpClient.post<Post[]>(this.url + 'getAllPosts', user, {}).pipe(catchError(this.handleError));
  }

  public fetchProfileDetails(profile: any): Observable<Profile> {
    return this.httpClient.post<Profile>(this.url + 'getUserProfile', profile, {}).pipe(catchError(this.handleError));
  }

  public acceptProfileDetails(profile: any): Observable<Profile> {
    return this.httpClient.post<Profile>(this.url + 'updateUserProfile', profile, {}).pipe(catchError(this.handleError));
  }

  public getAllUserDetails(user: any): Observable<User[]> {
    return this.httpClient.post<User[]>(this.url + 'getAllUserDetails', user, {}).pipe(catchError(this.handleError));
  }

  public addNewFriendRequest(senderEmail: string, receiverEmail: string): Observable<void> {
    const formdata: FormData = new FormData();
    formdata.append('senderEmail', senderEmail);
    formdata.append('receiverEmail', receiverEmail);
    return this.httpClient.post<void>(this.url + 'addNewFriendRequest', formdata, {
      responseType: 'json'
    }).pipe(catchError(this.handleError));
  }

  public getUserAllPendingFriendRequests(user: User): Observable<string[]> {
    return this.httpClient.post<string[]>(this.url + 'getUserAllPendingFriendRequests', user, {}).
    pipe(catchError(this.handleError));
  }

  public acceptFriendRequest(senderEmailID: string, receiverEmailID: string): Observable<void> {
    const formdata: FormData = new FormData();
    formdata.append('senderEmailID', senderEmailID);
    formdata.append('receiverEmailID', receiverEmailID);
    return this.httpClient.post<void>(this.url + 'addUserFriend', formdata, {
      responseType: 'json'
    }).pipe(catchError(this.handleError));
  }

  public rejectFriendRequest(senderEmailID: string, receiverEmailID: string): Observable<void> {
    const formdata: FormData = new FormData();
    formdata.append('senderEmailID', senderEmailID);
    formdata.append('receiverEmailID', receiverEmailID);
    return this.httpClient.post<void>(this.url + 'rejectFriendRequest', formdata, {
      responseType: 'json'
    }).pipe(catchError(this.handleError));
  }


  pushFileToStorage(file: File, profileID: number, albumName: string, photo: Photo): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('profileID', profileID.toString());
    formdata.append('albumName', albumName);
    formdata.append('photoDate', photo.photoDate);
    formdata.append('photoTime', photo.photoTime);
    const req = new HttpRequest('POST', this.url + 'api/file/upload', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }

  getAllPhotos(): Observable<Photo[]> {
    return this.httpClient.get<Photo[]>(this.url + 'api/file/retrieve').pipe(catchError(this.handleError));
  }

  getAllAlbumPhotos(album: any): Observable<Photo[]> {
    return this.httpClient.post<Photo[]>(this.url + 'getAllProfilePhotos', album, {}).pipe(catchError(this.handleError));
  }

  getAllUserPhotos(profile: any): Observable<Photo[]> {
    return this.httpClient.post<Photo[]>(this.url + 'getAllUserPhotos', profile, {}).pipe(catchError(this.handleError));
  }

  getUserAllFriends(user: any): Observable<string[]> {
    return this.httpClient.post<string[]>(this.url + 'getAllUserFriends', user, {}).pipe(catchError(this.handleError));
  }

  getAlbumDisplay(album: any): Observable<Photo> {
    return this.httpClient.post<Photo>(this.url + 'getAlbumPhoto', album, {}).pipe(catchError(this.handleError));
  }

  getUserFromProfile(profile: any): Observable<User> {
    return this.httpClient.post<User>(this.url + 'getUserFromProfile', profile, {}).pipe(catchError(this.handleError));
  }

  getFriendPost(profile: any): Observable<Post[]> {
    return this.httpClient.post<Post[]>(this.url + 'getFriendPost', profile, {}).pipe(catchError(this.handleError));
  }

  private handleError(error: any) {
    if (error instanceof ErrorEvent) {
      console.error(`1 An ErrorEvent occurred: `, error.error.message);
      return throwError(error.error.message);
    } else if (error instanceof HttpErrorResponse) {
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    } else if (error instanceof TypeError) {
      console.error(`3 TypeError has occured ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occured ${error.message}, body was: ${error.stack}`);
    }
  }
}
