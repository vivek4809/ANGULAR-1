import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  _fullName: string;
  constructor() { }

  ngOnInit() {
    const user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
    this._fullName = user.firstName + ' ' + user.lastName;
  }

}
