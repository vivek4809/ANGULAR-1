import { Photos } from './../../photos';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Image } from 'src/app/image';



@Component({
  selector: 'app-form-upload',
  templateUrl: './form-upload.component.html',
  styleUrls: ['./form-upload.component.css']
})
export class FormUploadComponent implements OnInit {

  imageUrl = '/assets/images/img11.png';
  fileToUpload: File = null;
  selectedFiles: FileList;
  retrieveFiles: Image[];
  currentFileUpload: File;
  fileData: Photos;
  progress: { percentage: number } = { percentage: 0 };
  byteData: Blob;

  error: string;

  constructor(private capbookServices: CapbookServicesService) { }

  ngOnInit() {
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  handleFileInput(file: FileList) {
  this.fileToUpload = file.item(0);
  const reader = new FileReader();
  reader.onload = (event: any) => {
    this.imageUrl = event.target.result;
  };
  reader.readAsDataURL(this.fileToUpload);
  }

  upload() {
    this.progress.percentage = 0;
    const fd = new FormData();

    fd.append('image', this.fileToUpload, this.fileToUpload.name);
    this.capbookServices.pushFileToStorage(this.fileToUpload).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
      }
    });

    this.selectedFiles = undefined;
  }

  retrieve() {
    console.log('Retreicve pics');
    this.capbookServices.getAllPhotos().subscribe(
      tempFile => {
        console.log('image aa gyi');
        this.fileData = tempFile;
        this.byteData = this.fileData.data;
    },
    error => {
      this.error = error;
    }
    );

  }

}
