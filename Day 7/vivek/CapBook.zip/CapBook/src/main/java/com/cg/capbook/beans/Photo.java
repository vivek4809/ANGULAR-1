package com.cg.capbook.beans;

import java.util.Arrays;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
public class Photo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="photoIDGenerator")
	@SequenceGenerator(name="photoIDGenerator", initialValue=1, allocationSize=0)
	private int photoID;
	private String photoName;
	private String photoType;
	@Lob
	private byte[] data;
	private String location;
	private String photoDate, photoTime;
	//	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE})
	//	@MapKey
	//	private Map<String, User> taggedFriends;
	@ManyToOne
	@JsonManagedReference
	private Album album;
	private int likesCount, dislikesCount;
	//	@OneToMany(cascade=CascadeType.ALL, mappedBy="photo", orphanRemoval=true)
	//	@MapKey
	//	private Map<String, Comment> comments;
	public Photo() {}
	public Photo(String photoName, String photoType, byte[] data) {
		super();
		this.photoName = photoName;
		this.photoType = photoType;
		this.data = data;
	}
	public Photo(String photoName, String photoType, byte[] data, String location, String photoDate, String photoTime,
			Album album, int likesCount, int dislikesCount) {
		super();
		this.photoName = photoName;
		this.photoType = photoType;
		this.data = data;
		this.location = location;
		this.photoDate = photoDate;
		this.photoTime = photoTime;
		this.album = album;
		this.likesCount = likesCount;
		this.dislikesCount = dislikesCount;
	}
	public Photo(int photoID, String photoName, String photoType, byte[] data, String location, String photoDate,
			String photoTime, Album album, int likesCount, int dislikesCount) {
		super();
		this.photoID = photoID;
		this.photoName = photoName;
		this.photoType = photoType;
		this.data = data;
		this.location = location;
		this.photoDate = photoDate;
		this.photoTime = photoTime;
		this.album = album;
		this.likesCount = likesCount;
		this.dislikesCount = dislikesCount;
	}
	public int getPhotoID() {
		return photoID;
	}
	public void setPhotoID(int photoID) {
		this.photoID = photoID;
	}
	public String getPhotoName() {
		return photoName;
	}
	public void setPhotoName(String photoName) {
		this.photoName = photoName;
	}
	public String getPhotoType() {
		return photoType;
	}
	public void setPhotoType(String photoType) {
		this.photoType = photoType;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPhotoDate() {
		return photoDate;
	}
	public void setPhotoDate(String photoDate) {
		this.photoDate = photoDate;
	}
	public String getPhotoTime() {
		return photoTime;
	}
	public void setPhotoTime(String photoTime) {
		this.photoTime = photoTime;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public int getLikesCount() {
		return likesCount;
	}
	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}
	public int getDislikesCount() {
		return dislikesCount;
	}
	public void setDislikesCount(int dislikesCount) {
		this.dislikesCount = dislikesCount;
	}
	@Override
	public String toString() {
		return "Photo [photoID=" + photoID + ", photoName=" + photoName + ", photoType=" + photoType + ", data="
				+ Arrays.toString(data) + ", location=" + location + ", photoDate=" + photoDate + ", photoTime=" + photoTime
				+ ", album=" + album + ", likesCount=" + likesCount + ", dislikesCount=" + dislikesCount + "]";
	}
}
