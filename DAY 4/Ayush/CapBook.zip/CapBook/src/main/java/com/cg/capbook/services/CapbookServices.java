package com.cg.capbook.services;

import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;

public interface CapbookServices {
	public User customerLogin(String emailID, String password) throws UserDetailsNotFoundException, UserInvalidDetailsException;
	public User registerCustomer(User user) throws UserInvalidDetailsException;
	public User updateUserDetails(User user);
	public User getUserDetails(String emailID) throws UserDetailsNotFoundException;
}
