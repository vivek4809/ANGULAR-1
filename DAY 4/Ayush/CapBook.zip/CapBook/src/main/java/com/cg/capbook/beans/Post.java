package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="postIDGenerator")
	@SequenceGenerator(name="postIDGenerator", initialValue=1, allocationSize=0)
	private int postID;
	private String postText;
	private String postDate, postTime;
	private int likesCount, dislikesCount;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<String, Comment> comments;
	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<String, User> taggedFriends;
	@ManyToOne
	private Profile profile;
}
