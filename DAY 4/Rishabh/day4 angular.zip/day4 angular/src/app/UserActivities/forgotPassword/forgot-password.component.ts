import { User } from './../user';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  _emailID: string;
  _firstSecurityAnswer: string;
  _secondSecurityAnswer: string;
  _password: string;
  _confirmPassword: string;
  _user: User;
  _message: string;
  _error: string;

  constructor(private route: ActivatedRoute, private router: Router, private capbookServices: CapbookServicesService) { }

  get emailID(): string {
    return this._emailID;
  }
  set emailID(value: string) {
    this._emailID = value;
  }

  get firstSecurityAnswer(): string {
    return this._firstSecurityAnswer;
  }
  set firstSecurityAnswer(value: string) {
    this._firstSecurityAnswer = value;
  }

  get secondSecurityAnswer(): string {
    return this._secondSecurityAnswer;
  }
  set secondSecurityAnswer(value: string) {
    this._secondSecurityAnswer = value;
  }

  get password(): string {
    return this._password;
  }
  set password(value: string) {
    this._password = value;
  }

  get confirmPassword(): string {
    return this._confirmPassword;
  }
  set confirmPassword(value: string) {
    this._confirmPassword = value;
  }

  ngOnInit() {
  }

  onClick() {
    const findUser: any = {
      emailID: this.emailID,
    };

    this.capbookServices.fetchUserDetails(findUser).subscribe(
        user => {
          this._user = user;
          console.log('Fetched Details!');
          console.log(JSON.stringify(this._user));
          if (this._user.password.toLowerCase() === this.password.toLowerCase()) {
            console.log('Old Password and New Password match!');
          } else if (this.password.toLowerCase() !== this.confirmPassword.toLowerCase()) {
            console.log('Password do not match');
          } else if (this._user.firstSecurityAnswer.toLowerCase() !== this.firstSecurityAnswer.toLowerCase()) {
            console.log('Incorrect Security Answer 1');
          } else if (this._user.secondSecurityAnswer.toLowerCase() !== this.secondSecurityAnswer.toLowerCase()) {
            console.log('Incorrect Security Answer 2');
          } else {
            const updateUser: any = {
              emailID : this.emailID,
              password : this.password,
            };
            this.capbookServices.changePassword(updateUser).subscribe(
                success => {
                  console.log('Password Updated');
                  this.router.navigate(['/signin']);
                }
              ,
            );
          }
        }
      ,
        error => {
          console.log('error fetching details');
        }
    );

    /* this.capbookServices.forgotPassword(user1).subscribe(
      tempmessage => {
        this._message = 'You have succesfully reset your password.';
        console.log(this._message);
      },
      error=>{
        this._error=error;
        console.log("error");
      }
    ); */
  }

}
