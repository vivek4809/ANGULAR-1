import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wall-posts',
  templateUrl: './wall-posts.component.html',
  styleUrls: ['./wall-posts.component.css']
})
export class WallPostsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
