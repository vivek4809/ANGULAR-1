import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  _profileName: string;
  user: User;
  requestsList: string[];
  userList: User[];
  requestedUsersList: User[] = [];
  senderEmail: string;
  constructor(private capbookService: CapbookServicesService) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('loggedUser'));
    this._profileName = this.user.firstName + ' ' + this.user.lastName;
    this.capbookService.getUserAllPendingFriendRequests(this.user).subscribe(
      tempUserList => {
        this.requestsList = tempUserList;
        const length = this.requestsList.length;
        console.log('length' + length);
        for (let i = 0 ; i < length ; i++) {
          const user: any = {
            emailID: this.requestsList[i]
          };
          this.capbookService.fetchUserDetails(user).subscribe(
            tempUser => {
              console.log(JSON.stringify(tempUser));
              this.requestedUsersList.push(tempUser);
            }
            ,
            error => {
            }
          );
          }
      }
      ,
      error => {
      }
    );

  }

  onClick() {
    this.capbookService.getAllUserDetails(this.user).subscribe(
      tempUserList => {
        this.userList = tempUserList;
        console.log(JSON.stringify(this.userList));
      }
      ,
      error => {
      }
    );
  }
  addFriend(email: string) {
    console.log(email);
    this.senderEmail = this.user.emailID;
    const receiverEmail = email;
    this.capbookService.addNewFriendRequest(this.senderEmail, receiverEmail).subscribe(
      tempUserList => {
      }
      ,
      error => {
      }
    );
    console.log('Friend Request Sent!!!');
    this.ngOnInit();
  }

  acceptFriendRequest(senderEmailID: string) {
    this.capbookService.acceptFriendRequest(senderEmailID, this.user.emailID).subscribe(
      tempUserList => {},
      error => {}
    );
    window.location.reload();
  }

  ignoreFriendRequest(senderEmailID: string) {
    this.capbookService.rejectFriendRequest(senderEmailID, this.user.emailID).subscribe(
      tempUserList => {}
      ,
      error => {}
    );
    this.ngOnInit();
    window.location.reload();
  }

}
