export interface Image {
    photoID: string,
    photoName: string,
    photoType: string
}
