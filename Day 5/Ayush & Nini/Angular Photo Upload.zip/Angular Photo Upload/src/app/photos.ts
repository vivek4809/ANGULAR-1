export interface Photos {
  photoId: string;
  photoName: string;
  photoType: string;
  data: Blob;
}
