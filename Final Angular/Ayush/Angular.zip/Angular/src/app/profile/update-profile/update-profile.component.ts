import { Profile } from './../../interfaces/Profile/profile';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interfaces/User/user';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  profile: Profile;
  error: string;

  _bio: string;
  _work: string;
  _education: string;
  _relationship: string;
  _currentCity: string;
  _homeTown: string;
  user: User;
  successMessage: string;
  get bio(): string {
    return this._bio;
  }
  set bio(value: string) {
    this._bio = value;
  }
  get work(): string {
    return this._work;
  }
  set work(value: string) {
    this._work = value;
  }
  get education(): string {
    return this._education;
  }
  set education(value: string) {
    this._education = value;
  }
  get relationship(): string {
    return this._relationship;
  }
  set relationship(value: string) {
    this._relationship = value;
  }
  get currentCity(): string {
    return this._currentCity;
  }
  set currentCity(value: string) {
    this._currentCity = value;
  }
  get homeTown(): string {
    return this._homeTown;
  }
  set homeTown(value: string) {
    this._homeTown = value;
  }

  constructor(private capbookService: CapbookServicesService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('loggedUser'));
    this.capbookService.fetchUserDetails(this.user).subscribe(
      tempUser => {
        this.user = tempUser;
        console.log(this.user.age);
      },
      error => {
        this.error = error;
      });

    this.capbookService.fetchProfileDetails(this.user.profile).subscribe(
      tempProfile => {
        this.profile = tempProfile;
        this._bio = this.profile.bio;
        this._work = this.profile.work;
        this._education = this.profile.education;
        this._relationship = this.profile.relationship;
        this._currentCity = this.profile.currentCity;
        this._homeTown = this.profile.homeTown;
      },
      error => {
        this.error = error;
      });
  }

  acceptProfile() {
    const _profile: any = {
      profileID: this.user.profile.profileID,
      bio: this._bio,
      work: this.work,
      education: this.education,
      relationship: this.relationship,
      currentCity: this.currentCity,
      homeTown: this.homeTown,
    };
    this.capbookService.acceptProfileDetails(_profile).subscribe(

      tempProfile => {
        this.profile = tempProfile;
        this.successMessage = 'Profile has been updated Successfully';
      },
      error => {
        this.error = error;
      });
  }

}
