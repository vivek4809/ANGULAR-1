import { Router, ActivatedRoute } from '@angular/router';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Profile } from './../../interfaces/Profile/profile';
import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-about',
  templateUrl: './profile-about.component.html',
  styleUrls: ['./profile-about.component.css']
})
export class ProfileAboutComponent implements OnInit {

  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _profile: Profile;
  emailId: string;
  error: string;

  constructor(private capbookServices: CapbookServicesService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.capbookServices.fetchUserDetails(this._user).subscribe(
      tempUser => {
        this._user = tempUser;
        console.log(this._user.age);
      },
      error => {
        this.error = error;
      });

    this.capbookServices.fetchProfileDetails(this._user.profile).subscribe(
      tempProfile => {
        this._profile = tempProfile;
      },
      error => {
        this.error = error;
      });
  }

}
