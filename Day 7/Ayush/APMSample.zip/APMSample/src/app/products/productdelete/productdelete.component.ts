import { ProductService } from './../../services/product.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-productdelete',
  templateUrl: './productdelete.component.html',
  styleUrls: ['./productdelete.component.css']
})
export class ProductdeleteComponent implements OnInit {
  pageTitle: string = 'Product Detail';
  errorMessage: string;
  product: Product;
  result: string;
  enableDeleteSection: boolean;

  constructor(private route: ActivatedRoute, private router: Router, private productService: ProductService) { }

  ngOnInit() {
    this.enableDeleteSection = true;
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    this.productService.getProductDetails(productId).subscribe(
        tempProduct => {
          this.product = tempProduct;
        }
      ,
        errorMessage => {
          this.errorMessage = errorMessage;
        }
    );
  }

  deleteItemDetails(): void {
    this.enableDeleteSection = false;
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    console.log(productId);
    this.productService.removeProductDetails(productId).subscribe(
        (success: any) => {
          this.result = 'Product with Product ID: ' + productId + ' successfully deleted!';
          /* this.router.navigate(['/products', {result : this.result}]); */
        }
      ,
        error => {
          this.errorMessage = error;
        }
    );
  }

  public navigateBack(): void {
    this.router.navigate(['/products']);
  }

}
