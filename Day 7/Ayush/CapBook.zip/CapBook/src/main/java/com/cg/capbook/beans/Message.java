package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

//@Entity
public class Message {
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO, generator="messageIDGenerator")
//	@SequenceGenerator(name="messageIDGenerator", initialValue=1, allocationSize=0)
//	private int messageID;
//	private String messageString;
//	private String messageDate, messageTime;
//	@ManyToOne
//	private User recepientUser;
//	@ManyToOne
//	private Profile profile;
}
