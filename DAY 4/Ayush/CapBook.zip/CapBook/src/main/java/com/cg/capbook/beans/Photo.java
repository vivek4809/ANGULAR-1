package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
public class Photo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="photoIDGenerator")
	@SequenceGenerator(name="photoIDGenerator", initialValue=1, allocationSize=0)
	private int photoID;
	private String location;
	private String photoDate, photoTime;
	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE})
	@MapKey
	private Map<String, User> taggedFriends;
	@ManyToOne
	private Album album;
	private int likesCount, dislikesCount;
	@OneToMany(cascade=CascadeType.ALL, mappedBy="photo", orphanRemoval=true)
	@MapKey
	private Map<String, Comment> comments;
}
