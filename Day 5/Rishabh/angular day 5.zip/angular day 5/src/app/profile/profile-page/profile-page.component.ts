import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/interfaces/User/user';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  bio: string="Add Bio!!";
  _profileName:string;
  _postText: string;
  errorMessage:string;
  constructor(private route: ActivatedRoute, private router: Router, private capbookService:  CapbookServicesService,private datePipe: DatePipe) { }
  
  get postText():string{
    return this._postText;
  }
  set postText(value:string){
    this._postText=value;
  }

  ngOnInit() {
    var user:User=JSON.parse(sessionStorage.getItem("loggedUser"));
    this._profileName=user.firstName+' '+user.lastName;
    this.bio;
  }

  createPost(){
    var _postDate=new Date();
    const post:any={
      postText:this.postText,
      postDate:this.datePipe.transform(_postDate, 'yyyy-MM-dd'),
      postTime:this.datePipe.transform(_postDate,'hh:mm:ss a'),
      likesCount:0,
      dislikesCount:0
    };
    this.capbookService.updateStatus(post).subscribe(
      user => {
        }
    ,
      error => {
        this.errorMessage = 'Status Not Updated!!';
      }
  );
  }
  
}
