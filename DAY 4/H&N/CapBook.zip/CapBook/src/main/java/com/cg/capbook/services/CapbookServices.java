package com.cg.capbook.services;

import java.io.IOException;
import java.util.List;

import org.apache.commons.fileupload.FileUploadBase.IOFileUploadException;

import com.cg.capbook.beans.Photos;
import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.PhotoStorageException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;

public interface CapbookServices {
	public User customerLogin(String emailID, String password) throws UserDetailsNotFoundException, UserInvalidDetailsException;
	public User registerCustomer(User user) throws UserInvalidDetailsException;
	public User updateUserDetails(User user);
	public User getUserDetails(String emailID) throws UserDetailsNotFoundException;
	public Photos storePhoto(Photos photo) throws PhotoStorageException;
	public List<Photos> retrieveAllPhotos() throws PhotoStorageException;
}
