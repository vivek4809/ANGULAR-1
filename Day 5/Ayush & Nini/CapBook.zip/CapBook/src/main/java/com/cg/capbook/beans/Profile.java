package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;
@Entity
public class Profile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="profileIDGenerator")
	@SequenceGenerator(name="profileIDGenerator", initialValue=1, allocationSize=0)
	private int profileID;
	private String bio, about, work, education, relationship, currentCity, homeTown;
	private String joiningDate;
	/*@OneToOne(cascade=CascadeType.ALL, orphanRemoval=true)
	private Photo profilePic;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Album> albums;
	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, mappedBy="")
	@MapKey
	private Map<String, User> friends;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Post> posts;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Message> messages;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Notification> notifications;*/
	@OneToOne
	@JsonBackReference
	private User user;
	public Profile() {}
	/*public Profile(String bio, String about, String work, String education, String relationship, String currentCity,
			String homeTown, String joiningDate, Photo profilePic, Map<Integer, Album> albums,
			Map<String, User> friends, Map<Integer, Post> posts, Map<Integer, Message> messages,
			Map<Integer, Notification> notifications, User user) {
		super();
		this.bio = bio;
		this.about = about;
		this.work = work;
		this.education = education;
		this.relationship = relationship;
		this.currentCity = currentCity;
		this.homeTown = homeTown;
		this.joiningDate = joiningDate;
		this.profilePic = profilePic;
		this.albums = albums;
		this.friends = friends;
		this.posts = posts;
		this.messages = messages;
		this.notifications = notifications;
		this.user = user;
	}
	public Profile(int profileID, String bio, String about, String work, String education, String relationship,
			String currentCity, String homeTown, String joiningDate, Photo profilePic, Map<Integer, Album> albums,
			Map<String, User> friends, Map<Integer, Post> posts, Map<Integer, Message> messages,
			Map<Integer, Notification> notifications, User user) {
		super();
		this.profileID = profileID;
		this.bio = bio;
		this.about = about;
		this.work = work;
		this.education = education;
		this.relationship = relationship;
		this.currentCity = currentCity;
		this.homeTown = homeTown;
		this.joiningDate = joiningDate;
		this.profilePic = profilePic;
		this.albums = albums;
		this.friends = friends;
		this.posts = posts;
		this.messages = messages;
		this.notifications = notifications;
		this.user = user;
	}*/
	public Profile(String bio, String about, String work, String education, String relationship, String currentCity,
			String homeTown, String joiningDate) {
		super();
		this.bio = bio;
		this.about = about;
		this.work = work;
		this.education = education;
		this.relationship = relationship;
		this.currentCity = currentCity;
		this.homeTown = homeTown;
		this.joiningDate = joiningDate;
	}
	public int getProfileID() {
		return profileID;
	}
	public void setProfileID(int profileID) {
		this.profileID = profileID;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	public String getHomeTown() {
		return homeTown;
	}
	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}
	public String getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}
	/*public Photo getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(Photo profilePic) {
		this.profilePic = profilePic;
	}
	public Map<Integer, Album> getAlbums() {
		return albums;
	}
	public void setAlbums(Map<Integer, Album> albums) {
		this.albums = albums;
	}
	public Map<String, User> getFriends() {
		return friends;
	}
	public void setFriends(Map<String, User> friends) {
		this.friends = friends;
	}
	public Map<Integer, Post> getPosts() {
		return posts;
	}
	public void setPosts(Map<Integer, Post> posts) {
		this.posts = posts;
	}
	public Map<Integer, Message> getMessages() {
		return messages;
	}
	public void setMessages(Map<Integer, Message> messages) {
		this.messages = messages;
	}
	public Map<Integer, Notification> getNotifications() {
		return notifications;
	}
	public void setNotifications(Map<Integer, Notification> notifications) {
		this.notifications = notifications;
	}*/
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
