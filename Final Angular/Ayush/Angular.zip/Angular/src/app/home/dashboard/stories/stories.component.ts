import { User } from 'src/app/interfaces/User/user';
import { Post } from './../../../interfaces/Post/post';
import { Component, OnInit } from '@angular/core';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';

@Component({
  selector: 'app-stories',
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.css']
})
export class StoriesComponent implements OnInit {
  _friendsPost: Post[];
  _friends: User[] = [];
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  constructor(private capbookServices: CapbookServicesService) { }

  ngOnInit() {
    this.capbookServices.getFriendPost(this._user.profile).subscribe(
      posts => {
        this._friendsPost = posts;
        for (let i = 0; i < posts.length; i++) {
          this.capbookServices.getUserFromProfile(this._friendsPost[i].profile).subscribe(
            user => {
              this._friends.push(user);
            }
          );
        }
      }
    );
  }

}
