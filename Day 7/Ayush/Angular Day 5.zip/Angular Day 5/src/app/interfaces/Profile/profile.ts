import { User } from './../User/user';
export interface Profile {
  profileID: number;
  bio: string;
  about: string;
  work: string;
  education: string;
  relationship: string;
  currentCity: string;
  homeTown: string;
  joiningDate: string;
  user: User;
}
