package com.cg.capbook.stepdefinations;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capbook.pagebeans.UserRegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

	
	
public class UserRegistrationStepDefination {

	private WebDriver driver;
	private UserRegistrationPage userRegistrationPage;
	
	@Given("^User is on CapBook signup page$")
	public void user_is_on_CapBook_signup_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:4200/index/signup");
		userRegistrationPage = PageFactory.initElements(driver, UserRegistrationPage.class);
	}

	@When("^User Enters his all data correctly$")
	public void user_Enters_his_all_data_correctly() throws Throwable {
		userRegistrationPage.setFirstName("Vivek");
		userRegistrationPage.setLastName("Singla");
		userRegistrationPage.setEmailID("vivek.g.singla@gmail.com");
		userRegistrationPage.setPassword("vivek1234");
		userRegistrationPage.setConfirmPassword("vivek1234");
		userRegistrationPage.setDateOfBirth("09/18/1996");
		userRegistrationPage.setAge("22");
		userRegistrationPage.setMobileNo("9874561230");
		userRegistrationPage.clickRadio1();
		userRegistrationPage.setFirstSecurityAnswer("Horse");
		userRegistrationPage.setSecondSecurityAnswer("Pasta");
		userRegistrationPage.clickSignUp();
	}

	@Then("^User gets registered and successfull message is displayed\\.$")
	public void user_gets_registered_and_successfull_message_is_displayed() throws Throwable {
		String actualMessage = userRegistrationPage.getMessage();
		String expectedMessage = "Registration Successful!!";		
		
		System.out.println("Message is"+actualMessage);
		System.out.println("Message2 is"+expectedMessage);
		assertEquals(expectedMessage, actualMessage);
	}

}
