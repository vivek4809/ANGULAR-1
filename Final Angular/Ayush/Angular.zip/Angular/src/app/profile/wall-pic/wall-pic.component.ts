import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { User } from 'src/app/interfaces/User/user';
import { Photo } from './../../interfaces/Photo/photo';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wall-pic',
  templateUrl: './wall-pic.component.html',
  styleUrls: ['./wall-pic.component.css']
})
export class WallPicComponent implements OnInit {

  _wallPhotos: Photo[];
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _album: any = {
    albumName: 'Wall Pic Album',
    profile: this._user.profile
  };
  _imgData: Blob;
  constructor(private capbookService: CapbookServicesService) { }


  ngOnInit() {
    this.capbookService.getAllAlbumPhotos(this._album).subscribe(
      albumPhotosList => {
        this._wallPhotos = albumPhotosList;
        this._imgData = this._wallPhotos[0].data;
      }
    );
  }

}
