package com.cg.capbook.services;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cg.capbook.beans.FriendList;
import com.cg.capbook.beans.FriendRequest;
import com.cg.capbook.beans.Photo;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.Profile;
import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.FriendListDAO;
import com.cg.capbook.daoservices.FriendRequestDAO;
import com.cg.capbook.daoservices.PhotosDAO;
import com.cg.capbook.daoservices.PostDAO;
import com.cg.capbook.daoservices.ProfileDAO;
import com.cg.capbook.daoservices.UserDAO;
import com.cg.capbook.exceptions.EmptyFriendListException;
import com.cg.capbook.exceptions.FriendRequestException;
import com.cg.capbook.exceptions.PhotoStorageException;
import com.cg.capbook.exceptions.PostsNotFoundException;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.exceptions.UserInvalidDetailsException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;

@Component("capbookServices")
public class CapbookServicesImpl implements CapbookServices {

	@Autowired
	private UserDAO userDAO;
	@Autowired
	private PhotosDAO photoDAO;
	@Autowired
	private ProfileDAO profileDAO;
	@Autowired
	private PostDAO postDAO;
	@Autowired
	private FriendRequestDAO friendRequestDAO;
	@Autowired
	private FriendListDAO friendListDAO;
	
	@Override
	public User saveUserDetails(User user) {
		return userDAO.save(user);
	}
	
	@Override
	public User customerLogin(String emailID, String password) throws UserDetailsNotFoundException, UserInvalidDetailsException {
		User user = userDAO.findById(emailID).orElseThrow(() -> 
				new UserDetailsNotFoundException("No details found for this user email address"));
		if (!password.equalsIgnoreCase(user.getPassword()))
			throw new UserInvalidDetailsException("The Email Address and Password do not match!");
		return user;
	}

	@Override
	public User registerCustomer(User user) throws UserInvalidDetailsException {
		final String VALID_EMAILID_REGEX = "^[A-z0-9._%+-]+@[A-z0-9.-]+\\.[A-z]{2,6}$";
		final String VALID_NAME_REGEX = "[A-z][A-z\\s]+";
		final String VALID_AGE_REGEX = "[1-9][0-9]+";
		final String VALID_MOBILE_NUMBER_REGEX = "[1-9][0-9]{9}";
		if (!Pattern.matches(VALID_EMAILID_REGEX, user.getEmailID()))	{
			System.out.println("Invalid Email Address");
			throw new UserInvalidDetailsException("Enter a valid Email Address");
		}
		if (!Pattern.matches(VALID_NAME_REGEX, user.getFirstName())) {
			System.out.println("Invalid First Name");
			throw new UserInvalidDetailsException("Enter a valid First Name");
		}
		if (!Pattern.matches(VALID_NAME_REGEX, user.getLastName())) {
			System.out.println("Invalid Last Name");
			throw new UserInvalidDetailsException("Enter a valid Last Name");
			}
		if (!Pattern.matches(VALID_AGE_REGEX, String.valueOf(user.getAge()))) {
			System.out.println("Invalid age");
			throw new UserInvalidDetailsException("Enter a valid Age");
		}
		if (!Pattern.matches(VALID_MOBILE_NUMBER_REGEX, String.valueOf(user.getMobileNo()))) {
			System.out.println("Invalid mobile number");
			throw new UserInvalidDetailsException("Enter a valid Mobile Number");
			}
		return userDAO.save(user);
	}

	@Override
	public User updateUserDetails(User user) {
		return userDAO.save(user);
	}

	@Override
	public User getUserDetails(String emailID) throws UserDetailsNotFoundException {
		return userDAO.findById(emailID).orElseThrow(() -> 
			new UserDetailsNotFoundException("No details found for this user email address"));
	}

	@Override
	public Photo storePhoto(Photo photo) throws PhotoStorageException {
		String photoName = StringUtils.cleanPath(photo.getPhotoName());
		try {
			if(photoName.contains("..")) {
				throw new PhotoStorageException("Sorry! Filename contains invalid path sequence " + photoName);
			}
			photo=photoDAO.save(photo);
			return photo;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new PhotoStorageException("Could not store file. Please try again!");
		}
	}

	@Override
	public List<Photo> retrieveAllPhotos() throws PhotoStorageException {
		return photoDAO.findAll();
	}

	@Override
	public Profile getUserProfile(String emailID) throws UserProfileNotFoundException {
		Profile profile = profileDAO.getUserProfile(emailID);
		if (profile == null)	throw new UserProfileNotFoundException("No profile found");
		return profile;
	}
	
	@Override
	public Profile getUserProfileById(int profileID) throws UserProfileNotFoundException {
		return profileDAO.findById(profileID).orElseThrow(() -> new UserProfileNotFoundException("No profile found"));
	}

	@Override
	public Profile setUserProfile(Profile profile) {
		return profileDAO.save(profile);
	}
	
	@Override
	public Post updatePost(Post post) {
		return postDAO.save(post);
	}
	
	@Override
	public List<Post> getAllPosts(int profileID) throws PostsNotFoundException {
		List<Post> posts = postDAO.findAllPosts(profileID);
		if (posts.isEmpty())	throw new PostsNotFoundException("No posts Found");
		return posts;
	}

	@Override
	public FriendRequest sendFriendRequest(String senderEmail, String receiverEmail)
			throws UserDetailsNotFoundException, FriendRequestException {
		User sender=userDAO.findById(senderEmail).orElseThrow(()->new UserDetailsNotFoundException("User Details Not found"));
		userDAO.findById(receiverEmail).orElseThrow(()->new UserDetailsNotFoundException("User Details Not found"));
		if(senderEmail.equals(receiverEmail)) throw new FriendRequestException("Cannot send to your own account");
		FriendList friendsList=friendListDAO.checkFriendList(senderEmail,receiverEmail);
		if(friendsList!=null)throw new FriendRequestException("Already friends"); 
		/*if(sender.getFriendList()!=null){
			for(String email:sender.getFriendList())
				if(receiverEmail.equals(email)) throw new FriendRequestException("Already friends");}*/
		FriendRequest request1=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		FriendRequest request2=friendRequestDAO.getFriendRequestId(receiverEmail,senderEmail);
		if(request1!=null) throw new FriendRequestException("Request already sent");
		if(request2!=null) throw new FriendRequestException("Request pending from sender");
		FriendRequest friendRequest=new FriendRequest(senderEmail,receiverEmail);
		friendRequestDAO.save(friendRequest);
		return friendRequest;
	}
	
	@Override
	public FriendRequest acceptFriendRequest(String senderEmail, String receiverEmail)
			throws UserDetailsNotFoundException, FriendRequestException {
		User sender=userDAO.findById(senderEmail).orElseThrow(()->new UserDetailsNotFoundException("Sender Details Not found"));
		User receiver=userDAO.findById(receiverEmail).orElseThrow(()->new UserDetailsNotFoundException("Receiver Details Not found"));
		FriendRequest request=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		if(request==null) throw new FriendRequestException("Request not found exception");	
		
		/*if(sender.getFriendList()==null) 
			sender.setFriendList(new ArrayList<>());
		if(receiver.getFriendList()==null) 
			receiver.setFriendList(new ArrayList<>());
		sender.getFriendList().add(receiverEmail);*/
		String fullName1=sender.getFirstName();
		FriendList friendsList=new FriendList(senderEmail, fullName1, receiverEmail);
		friendListDAO.save(friendsList);	
		/*receiver.getFriendList().add(senderEmail);*/
		String fullName2=receiver.getFirstName();
		FriendList friendsList2=new FriendList(receiverEmail,fullName2, senderEmail);
		friendListDAO.save(friendsList2);
		/*userDAO.save(sender);
		userDAO.save(receiver);*/
		friendRequestDAO.delete(request);
		return request;
	}


	@Override
	public List<User> getAllUserDetails() {
		return userDAO.findAll();
	}
	
	public List<FriendList> getUserFriendList(String emailId) throws UserDetailsNotFoundException, EmptyFriendListException {
		/*userDAO.findById(emailId).orElseThrow(() -> new UserDetailsNotFoundException());
		ArrayList<String> friendList = friendListDAO.getAllFriendsList(emailId);
		ArrayList<String> friendsList = new ArrayList<>();
		if (friendList.isEmpty())
			throw new EmptyFriendListException("Friend list is empty");
		for (String email : friendList)
			friendsList.add(userDAO.findById(email).get().getFullName());
		return friendsList;*/
		User user= userDAO.findById(emailId).orElseThrow(()->new UserDetailsNotFoundException());
		List<FriendList> friendsList=friendListDAO.getFriendList(emailId);
		return friendsList;
	}

	@Override
	public FriendRequest deleteFriendRequest(String senderEmail, String receiverEmail)
			throws UserDetailsNotFoundException, FriendRequestException {
		userDAO.findById(senderEmail).orElseThrow(()->new UserDetailsNotFoundException("Sender Details Not found"));
		userDAO.findById(receiverEmail).orElseThrow(()->new UserDetailsNotFoundException("Receiver Details Not found"));
		FriendRequest request=friendRequestDAO.getFriendRequestId(senderEmail, receiverEmail);
		if(request==null) throw new FriendRequestException("No Requests Found");
		 friendRequestDAO.deleteById(request.getRequestId());
		 return  request;                      
	}
  

	@Override
	public ArrayList<String> getAllFriendRequestSent(String receiverEmail)
			throws UserDetailsNotFoundException, EmptyFriendListException {
		userDAO.findById(receiverEmail).orElseThrow(() -> new UserDetailsNotFoundException("User not found"));
		ArrayList<String> friendList = friendRequestDAO.getAllFriendRequestSent(receiverEmail);
		if (friendList.isEmpty())
			throw new EmptyFriendListException("Friend list is empty");
		ArrayList<String> friendListName = new ArrayList<>();
		for (String email : friendList)
			friendListName.add(userDAO.findById(email).get().getFirstName());
		return friendListName;
	}

	@Override
	public ArrayList<String> getAllFriendRequestReceived(String senderEmail)
			throws UserDetailsNotFoundException, EmptyFriendListException {
		userDAO.findById(senderEmail).orElseThrow(() -> new UserDetailsNotFoundException("User not found"));
		ArrayList<String> friendList = friendRequestDAO.getAllFriendRequestReceived(senderEmail);
		if (friendList.isEmpty())
			throw new EmptyFriendListException("Friend list is empty");
		ArrayList<String> friendListName = new ArrayList<>();
		for (String email : friendList)
			friendListName.add(userDAO.findById(email).get().getFirstName());
		return friendListName;
	}

}
