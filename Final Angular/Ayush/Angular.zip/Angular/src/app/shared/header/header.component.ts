import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  _profileName: string;
  user: User;
  requestsList: string[];
  userList: User[];
  requestedUsersList: User[] = [];
  senderEmail: string;
  _userAllFriendEmailIDs: string[];
  _userAllFriends: User[] ;
  constructor(private capbookService: CapbookServicesService) { }

  ngOnInit() {
    this.user = JSON.parse(sessionStorage.getItem('loggedUser'));
    this._profileName = this.user.firstName + ' ' + this.user.lastName;
    this.capbookService.getUserAllPendingFriendRequests(this.user).subscribe(
      tempUserList => {
        this.requestsList = tempUserList;
        const length = this.requestsList.length;
        console.log('length' + length);
        for (let i = 0 ; i < length ; i++) {
          const user: any = {
            emailID: this.requestsList[i]
          };
          this.capbookService.fetchUserDetails(user).subscribe(
            tempUser => {
              console.log(JSON.stringify(tempUser));
              this.requestedUsersList.push(tempUser);
            }
            ,
            error => {
            }
          );
          }
      }
      ,
      error => {
      }
    );

    this.capbookService.getAllUserDetails(this.user).subscribe(
      tempUserList => {
        this.userList = tempUserList;
        console.log('all other users ' + JSON.stringify(this.userList));
        this.capbookService.getUserAllFriends(this.user).subscribe(
          tempFriendList => {
            this._userAllFriendEmailIDs = tempFriendList;
            const length = this._userAllFriendEmailIDs.length;
            const friendList: User[] = [];
            for (let i = 0 ; i < length ; i++) {
                const user: any = {
                emailID: this._userAllFriendEmailIDs[i]
              };
              this.capbookService.fetchUserDetails(user).subscribe(
                tempUser => {
                  friendList.push(tempUser);
                  this._userAllFriends = friendList;
                  console.log('friends !! ' + JSON.stringify(this._userAllFriends));
                }
                ,
                error => {
                }
              );
          }
        }
        ,
        error => {}
        );
    }
      ,
      error => {
      }
    );
}

  onClick() {
    console.log('friends 222222!! ' + JSON.stringify(this._userAllFriends));
    console.log('other users 222222!! ' + JSON.stringify(this.userList));
    this.getNonAddedUsers();
  }

  addFriend(email: string) {
    console.log(email);
    this.senderEmail = this.user.emailID;
    const receiverEmail = email;
    this.capbookService.addNewFriendRequest(this.senderEmail, receiverEmail).subscribe(
      tempUserList => {
      }
      ,
      error => {
      }
    );
    console.log('Friend Request Sent!!!');
    this.ngOnInit();
  }

  acceptFriendRequest(senderEmailID: string) {
    this.capbookService.acceptFriendRequest(senderEmailID, this.user.emailID).subscribe(
      tempUserList => {},
      error => {}
    );
    window.location.reload();
  }

  ignoreFriendRequest(senderEmailID: string) {
    this.capbookService.rejectFriendRequest(senderEmailID, this.user.emailID).subscribe(
      tempUserList => {}
      ,
      error => {}
    );
    this.ngOnInit();
    window.location.reload();
  }
  getNonAddedUsers() {
    const friendsLength = this._userAllFriends.length;
    let usersLength = this.userList.length;
    for ( let i = 0 ; i < friendsLength ; i++) {
      for ( let j = 0 ; j < usersLength ; j++) {
        if ( this._userAllFriends [i].emailID === this.userList[j].emailID ) {
          console.log('matched!!');
          this.userList.splice(j, 1);
          usersLength--;
          console.log('Filtered List ' + JSON.stringify(this.userList));
        }
      }
    }
  }

}
