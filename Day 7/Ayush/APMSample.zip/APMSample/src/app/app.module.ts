import { ProductdeleteComponent } from './products/productdelete/productdelete.component';
import { ProductdetailsComponent } from './products/productdetails/productdetails.component';
import { ProductService } from './services/product.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './products/product-list.component';
import { ConvertToSpacePipe } from './shared/convert-to-space.pipe';
import { StarComponent } from './shared/star.component';
import { HttpClientModule } from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { SearchProductComponent } from './search-product/search-product.component';
import { AddproductComponent } from './products/addproduct/addproduct.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ConvertToSpacePipe,
    StarComponent,
    WelcomeComponent,
    SearchProductComponent,
    ProductdetailsComponent,
    ProductdeleteComponent,
    AddproductComponent,
    ReactiveFormsModule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'products', component: ProductListComponent},
      { path: 'welcome', component: WelcomeComponent },
      { path: 'search-product', component: SearchProductComponent },
      { path: 'product/:id', component: ProductdetailsComponent },
      { path: 'productDel/:id', component: ProductdeleteComponent },
      { path: 'addproduct', component: AddproductComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full'}
    ]),
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
