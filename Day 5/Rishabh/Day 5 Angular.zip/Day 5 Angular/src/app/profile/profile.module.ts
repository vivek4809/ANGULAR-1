import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { ProfilePicComponent } from './profile-pic/profile-pic.component';
import { ProfilePageComponent } from './profile-page/profile-page.component';
import { WallPicComponent } from './wall-pic/wall-pic.component';
import { ProfileAboutComponent } from './profile-about/profile-about.component';
import { FriendsComponent } from './friends/friends.component';
import { PhotosComponent } from './photos/photos.component';
import { WallPostsComponent } from './wall-posts/wall-posts.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { CreatePostComponent } from './create-post/create-post.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ProfilePicComponent, ProfilePageComponent, WallPicComponent, ProfileAboutComponent, FriendsComponent, PhotosComponent, WallPostsComponent, UpdateProfileComponent, CreatePostComponent],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    SharedModule,
    FormsModule
  ],
  exports: [
    ProfilePicComponent
  ]
})
export class ProfileModule { }
