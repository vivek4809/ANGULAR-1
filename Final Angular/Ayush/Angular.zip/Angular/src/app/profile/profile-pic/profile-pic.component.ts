import { User } from 'src/app/interfaces/User/user';
import { Photo } from './../../interfaces/Photo/photo';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-pic',
  templateUrl: './profile-pic.component.html',
  styleUrls: ['./profile-pic.component.css']
})
export class ProfilePicComponent implements OnInit {

  _profilePhotos: Photo[];
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _album: any = {
    albumName: 'Profile Pic Album',
    profile: this._user.profile
  };
  _imgData: Blob;
  constructor(private capbookService: CapbookServicesService) { }

  ngOnInit() {
    this.capbookService.getAllAlbumPhotos(this._album).subscribe(
      albumPhotosList => {
        this._profilePhotos = albumPhotosList;
        this._imgData = this._profilePhotos[0].data;
      }
    );
  }

}
