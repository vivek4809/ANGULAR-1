package com.cg.capbook.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class UserRegistrationPage {

	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName;
	
	@FindBy(how = How.ID, id="lastName")
	private WebElement lastName;
	
	@FindBy(how = How.ID, id="emailID")
	private WebElement emailID;
	
	@FindBy(how = How.ID, id="password")
	private WebElement password;
	
	@FindBy(how = How.ID, id="confirmPassword")
	private WebElement confirmPassword;
	
	@FindBy(how = How.ID, id="dateOfBirth")
	private WebElement dateOfBirth;
	
	@FindBy(how = How.ID, id="age")
	private WebElement age;
	
	@FindBy(how = How.ID, id="mobileNo")
	private WebElement mobileNo;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"mat-radio-2\"]")
	private WebElement radio1;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"mat-radio-3\"]")
	private WebElement radio2;
	
	@FindBy(how = How.ID, id="firstSecurityAnswer")
	private WebElement firstSecurityAnswer;
	
	@FindBy(how = How.ID, id="secondSecurityAnswer")
	private WebElement secondSecurityAnswer;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"submitButton\"]")
	private WebElement button1;

	@FindBy(how = How.CLASS_NAME, className="successMessageDiv")
	private WebElement Message;

	public UserRegistrationPage() {
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getConfirmPassword() {
		return confirmPassword.getAttribute("value");
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword.sendKeys(confirmPassword);
	}

	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}

	public String getAge() {
		return age.getAttribute("value");
	}

	public void setAge(String age) {
		this.age.clear();
		this.age.sendKeys(age);
	}

	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.clear();
		this.mobileNo.sendKeys(mobileNo);
	}

	
	public String getFirstSecurityAnswer() {
		return firstSecurityAnswer.getAttribute("value");
	}

	public void setFirstSecurityAnswer(String firstSecurityAnswer) {
		this.firstSecurityAnswer.sendKeys(firstSecurityAnswer);
	}

	public String getSecondSecurityAnswer() {
		return secondSecurityAnswer.getAttribute("value");
	}

	public void setSecondSecurityAnswer(String secondSecurityAnswer) {
		this.secondSecurityAnswer.sendKeys(secondSecurityAnswer);
	}

	public void clickSignUp() {
		 button1.click();
	}

	public void clickRadio1() {
		radio1.click();
	}
	
	public void clickRadio2() {
		radio2.click();
	}
	
	public String getMessage() {
		return Message.getText();
	}


	
	
}
