import { DatePipe } from '@angular/common';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from './../../interfaces/Post/post';
import { User } from './../../interfaces/User/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  bio = 'Add Bio!!';
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));
  _posts: Post[];
  _postText: string;
  _photoCaption: string;
  _changePhoto = false;
  _changeProfilePhoto = false;
  errorMessage: string;

  constructor(private route: ActivatedRoute, private router: Router,
    private capbookService: CapbookServicesService, private datePipe: DatePipe) { }

  get postText(): string {
    return this._postText;
  }
  set postText(value: string) {
    this._postText = value;
  }
  get photoCaption(): string {
    return this._photoCaption;
  }
  set photoCaption(value: string) {
    this._photoCaption = value;
  }
  ngOnInit() {
    this.getAllPosts();
  }

  changePhotoHover() {
    this._changePhoto = !this._changePhoto;
  }

  changeProfilePhotoHover() {
    this._changeProfilePhoto = true;
  }

  resetFields() {
    this._changeProfilePhoto = false;
  }

  deletePost(postID: number) {
    const post: any = {
      postID : postID
    };
    this.capbookService.deletePost(post).subscribe(
      success => {
        this.ngOnInit();
      }
    );
  }

  createPost() {
    const _postDate = new Date();
    const post: any = {
      postText: this.postText,
      postDate: this.datePipe.transform(_postDate, 'yyyy-MM-dd'),
      postTime: this.datePipe.transform(_postDate, 'HH:mm:ss'),
      likesCount: 0,
      dislikesCount: 0,
      profile: this._user.profile
    };
    console.log(JSON.stringify(post));
    this.capbookService.updateStatus(post).subscribe(
      user => {
        this.ngOnInit();
        }
    ,
      error => {
        this.errorMessage = 'Status Not Updated!!';
      }
  );
  }

  getAllPosts() {
    this.capbookService.getAllPosts(this._user).subscribe(
      tempPosts => {
        this._posts = tempPosts;
      }
    ,
      error => {
        this.errorMessage = 'No posts found!!';
      }
  );
  }
}
