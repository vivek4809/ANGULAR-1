package com.cg.capbook.beans;


public class FriendList {
	private int friendId;
	
}
