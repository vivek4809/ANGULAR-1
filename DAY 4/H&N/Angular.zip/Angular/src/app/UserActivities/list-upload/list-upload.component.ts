import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';

@Component({
  selector: 'list-upload',
  templateUrl: './list-upload.component.html',
  styleUrls: ['./list-upload.component.css']
})
export class ListUploadComponent implements OnInit {
 
  showFile = false;
  fileUploads: Observable<string[]>;
 
  constructor(private capbookServices : CapbookServicesService) { }
 
  ngOnInit() {
  }
 
  showFiles(enable: boolean) {
    this.showFile = enable;
 
    if (enable) {
      this.fileUploads = this.capbookServices.getFiles();
    }
  }
}