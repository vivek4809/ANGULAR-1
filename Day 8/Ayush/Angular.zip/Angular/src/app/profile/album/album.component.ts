import { DatePipe } from '@angular/common';
import { Album } from './../../interfaces/Album/album';
import { User } from './../../interfaces/User/user';
import { CapbookServicesService } from './../../services/capbook-services.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {

  _albumList: Album[];
  _albumName: string;
  _addAlbum = false;
  _user: User = JSON.parse(sessionStorage.getItem('loggedUser'));

  get albumName(): string {
    return this._albumName;
  }

  set albumName(value: string) {
    this._albumName = value;
  }

  constructor(private capbookService: CapbookServicesService, private datePipe: DatePipe) { }

  ngOnInit() {
    this.getAllAlbums();
    }

  createNewAlbum() {
    this._addAlbum = true;
  }

  resetFields() {
    this._addAlbum = false;
  }

  onClick() {
    const album: any = {
      albumName: this.albumName,
      albumDate: this.datePipe.transform(new Date(), 'yyyy-MM-dd'),
      albumTime: this.datePipe.transform(new Date(), 'HH:mm:ss'),
      profile: this._user.profile
    };
    console.log(JSON.stringify(album));
    this.capbookService.createNewAlbum(album).subscribe(
      _album => {
        this.ngOnInit();
      },
      error => {}
    );
  }

  getAllAlbums() {
    this.capbookService.getAllUserAlbums(this._user.profile).subscribe(
        albumList => {
          this._albumList = albumList;
        }
      ,
        error => {}
    );
  }

}
