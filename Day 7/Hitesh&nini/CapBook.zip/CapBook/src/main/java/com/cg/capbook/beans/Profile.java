package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
public class Profile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="profileIDGenerator")
	@SequenceGenerator(name="profileIDGenerator", initialValue=1, allocationSize=0)
	private int profileID;
	private String bio, work, education, relationship, currentCity, homeTown;
	private String joiningDate;
//	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
//	@MapKey
//	@JsonBackReference
//	private Map<Integer, Album> albums;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	@JsonIgnore
	private Map<Integer, Post> posts;
	@OneToOne
	@JsonIgnore
	private User user;
	
	/*@OneToOne(cascade=CascadeType.ALL, orphanRemoval=true)
	private Photo profilePic;
	@OneToMany(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, mappedBy="")
	@MapKey
	private Map<String, User> friends;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Message> messages;
	@OneToMany(cascade=CascadeType.ALL, orphanRemoval=true, mappedBy="profile")
	@MapKey
	private Map<Integer, Notification> notifications;*/
	
	public Profile() {}
	public Profile(String bio, String work, String education, String relationship, String currentCity, String homeTown,
			String joiningDate, Map<Integer, Post> posts, User user) {
		super();
		this.bio = bio;
		this.work = work;
		this.education = education;
		this.relationship = relationship;
		this.currentCity = currentCity;
		this.homeTown = homeTown;
		this.joiningDate = joiningDate;
		this.posts = posts;
		this.user = user;
	}
	public Profile(int profileID, String bio, String work, String education, String relationship, String currentCity,
			String homeTown, String joiningDate, Map<Integer, Post> posts, User user) {
		super();
		this.profileID = profileID;
		this.bio = bio;
		this.work = work;
		this.education = education;
		this.relationship = relationship;
		this.currentCity = currentCity;
		this.homeTown = homeTown;
		this.joiningDate = joiningDate;
		this.posts = posts;
		this.user = user;
	}
	public int getProfileID() {
		return profileID;
	}
	public void setProfileID(int profileID) {
		this.profileID = profileID;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getCurrentCity() {
		return currentCity;
	}
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}
	public String getHomeTown() {
		return homeTown;
	}
	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}
	public String getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}
	public Map<Integer, Post> getPosts() {
		return posts;
	}
	public void setPosts(Map<Integer, Post> posts) {
		this.posts = posts;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	@Override
	public String toString() {
		return "Profile [profileID=" + profileID + ", bio=" + bio + ", work=" + work + ", education=" + education
				+ ", relationship=" + relationship + ", currentCity=" + currentCity + ", homeTown=" + homeTown
				+ ", joiningDate=" + joiningDate + ", posts=" + posts + ", user=" + user + "]";
	}
}
