package com.cg.capbook.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Album;

public interface AlbumDAO extends JpaRepository<Album, Integer> {
	@Query("SELECT a FROM Album a WHERE a.profile.profileID = :profileID")
	public List<Album> getAllUserAlbums(@Param("profileID") int profileID);
}
