package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

//@Entity
public class Comment {
//	@Id
//	private int commentID;
//	private String commentText;
//	private String commentDate, commentTime;
//	private int likesCount, dislikesCount;
//	@ManyToOne
//	private Profile profile;
//	@ManyToOne
//	private Photo photo;
//	@ManyToOne
//	private Post post;
}
